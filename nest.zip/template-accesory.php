<?php
/**
 * Template Name: Аксессуар
 * Template Post Type: project
 * 
 * Template Description...
 **/ 
while(have_posts()){
	the_post();
	the_title();
}
?>
TEMPLATE ACCES