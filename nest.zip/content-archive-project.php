<div class="wardrobe__item">
	<a href="<?php echo get_the_permalink() ?>" class="wardrobe__link">
		<img src="<?php echo get_the_post_thumbnail_url() ?>" alt="alt" class="img-responsive">
		<h3 class="wardrobe__title"><?php the_title() ?></h3>
	</a>
</div>